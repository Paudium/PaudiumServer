module.exports = {
    MONGODB: 'mongodb+srv://paulus:paudium_forever@cluster0.alubv.mongodb.net/paudiumdb?retryWrites=true&w=majority',
    // MONGODB:'mongodb://localhost:27017/test',
    SECRET_KEY: 'some very secret key'
}