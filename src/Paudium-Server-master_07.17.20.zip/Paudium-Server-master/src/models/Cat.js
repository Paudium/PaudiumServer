const mongoose = require('mongoose');

module.exports = mongoose.model("Cat",{name:String});